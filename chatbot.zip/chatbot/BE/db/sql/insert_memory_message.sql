INSERT INTO memory_messages (text, emotion)
VALUES (:text, :emotion);