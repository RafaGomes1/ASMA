class LLMResponse:
    def __init__(self, text):
        self.text = text
