import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { useChat } from '../contexts/ChatContext';

interface TextInputProps {
  loading: boolean;
}

const TextInput: React.FC<TextInputProps> = ({ loading }) => {
  const [message, setMessage] = useState('');
  const { sendTextMessage } = useChat();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !loading) {
      sendTextMessage(message);
      setMessage('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center w-full">
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Escreva sua mensagem..."
        className="flex-1 px-4 py-2 bg-gray-100 border border-gray-200 rounded-l-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
        disabled={loading}
      />
      <button
        type="submit"
        disabled={!message.trim() || loading}
        className={`px-4 py-2 bg-indigo-600 text-white rounded-r-full flex items-center justify-center ${
          !message.trim() || loading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-indigo-700'
        }`}
      >
        {loading ? (
          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
        ) : (
          <Send className="h-5 w-5" />
        )}
      </button>
    </form>
  );
};

export default TextInput;